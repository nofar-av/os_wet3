#ifndef __REQUEST_H__
#define __REQUEST_H__
#include "stats.h"

void requestHandle(int fd, Stats* thread_stats);

#endif
